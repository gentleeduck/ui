import { useClick, useDismiss, useFloating, useInteractions, useRole } from '@floating-ui/react'

import * as React from 'react'
import { useDynamicLayer } from '../layer'
import { DialogContext } from './dialog'
import type { DialogContextProps, DialogOptions } from './dialog.types'

export function useDialog({
  defaultOpen = false,
  open: controlledOpen,
  onOpenChange: setControlledOpen,
  closeButton = true,
  modal = false,
}: DialogOptions): ReturnType<typeof useFloating> & {
  open: boolean
  setOpen: (open: boolean) => void
  closeButton: boolean
  layer: ReturnType<typeof useDynamicLayer>
  descriptionId?: string
  labelId?: string
  modal?: boolean
  setDescriptionId: React.Dispatch<React.SetStateAction<string | undefined>>
  setLabelId: React.Dispatch<React.SetStateAction<string | undefined>>
  setTitleId: React.Dispatch<React.SetStateAction<string | undefined>>
  titleId?: string
} {
  const [uncontrolledOpen, setUncontrolledOpen] = React.useState(defaultOpen)
  const [labelId, setLabelId] = React.useState<string | undefined>()
  const [titleId, setTitleId] = React.useState<string | undefined>()
  const [descriptionId, setDescriptionId] = React.useState<string | undefined>()

  const open = controlledOpen ?? uncontrolledOpen
  const setOpen = setControlledOpen ?? setUncontrolledOpen
  const layer = useDynamicLayer({ open })

  const data = useFloating({
    onOpenChange: setOpen,
    open,
  })

  const context = data.context

  const click = useClick(context, {
    enabled: controlledOpen == null,
  })
  const dismiss = useDismiss(context, { outsidePressEvent: 'mousedown' })
  const role = useRole(context)

  const interactions = useInteractions([click, dismiss, role])

  return React.useMemo(
    () => ({
      open,
      setOpen,
      ...data,
      ...interactions,
      closeButton,
      descriptionId,
      layer,
      labelId,
      modal,
      setDescriptionId,
      setLabelId,
      setTitleId,
      titleId,
    }),
    [open, setOpen, interactions, data, labelId, descriptionId, setTitleId, layer],
  )
}

export const useDialogContext = (): NonNullable<DialogContextProps> => {
  const context = React.useContext(DialogContext)

  if (context == null) {
    throw new Error('Dialog components must be wrapped in <Dialog />')
  }

  return context
}
