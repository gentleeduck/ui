// 🦆 THIS FILE IS AUTO-GENERATED. DO NOT EDIT.

import { AuthMessages } from '../../examples/nestjs-react-query/server/src/auth/auth.messages'

/** 🦆
 * 🦆 Duckgen message registry.
 * 🦆
 * 🦆 Each group key points to either a const string array OR a const object record.
 * 🦆 Use the types below to build i18n dictionaries aligned with those sources.
 */
export type DuckgenMessageSources = {
  auth: typeof AuthMessages
}

/** 🦆
 * 🦆 All message group keys (for example: "auth", "users", "errors").
 */
export type DuckgenMessageGroup = keyof DuckgenMessageSources

/** 🦆
 * 🦆 Message key union for a specific group.
 * 🦆 Supports both array sources (values) and object sources (keys).
 * 🦆 If G is omitted, the result is the union of all message keys across all groups.
 */
export type DuckgenMessageKey<G extends DuckgenMessageGroup = DuckgenMessageGroup> =
  DuckgenMessageSources[G] extends readonly (infer V)[] ? V & string : keyof DuckgenMessageSources[G] & string

/** 🦆
 * 🦆 Dictionary shape for a single group.
 * 🦆 Keys are enforced by DuckgenMessageKey<G>.
 */
export type DuckgenMessageDictionary<G extends DuckgenMessageGroup = DuckgenMessageGroup> = Record<
  DuckgenMessageKey<G>,
  string
>

/** 🦆
 * 🦆 All groups mapped to their dictionaries.
 */
export type DuckgenMessageDictionaryByGroup = {
  [G in DuckgenMessageGroup]: DuckgenMessageDictionary<G>
}

/** 🦆
 * 🦆 Alias: language -> all group dictionaries.
 */
export type DuckGenI18nMessages = DuckgenMessageDictionaryByGroup

/** 🦆
 * 🦆 Language -> dictionary for a subset of groups (or all groups if G is omitted).
 * 🦆 Useful when you want a module-scoped i18n object.
 */
export type DuckgenI18n<Lang extends string, G extends DuckgenMessageGroup = DuckgenMessageGroup> = Record<
  Lang,
  DuckgenMessageDictionary<G>
>

/** 🦆
 * 🦆 Language -> all groups. This is the common top-level i18n shape.
 */
export type DuckgenI18nByGroup<Lang extends string> = Record<Lang, DuckGenI18nMessages>

/** 🦆
 * 🦆 Language -> scope -> messages.
 * 🦆
 * 🦆 Two modes:
 * 🦆 1) If ScopeOrMessages is a string scope name (example: "server"), the inner value is Messages.
 * 🦆 2) If ScopeOrMessages is already a messages type, it becomes the inner value and scope keys become string.
 */
export type DuckgenScopedI18nByGroup<
  Lang extends string,
  ScopeOrMessages extends string | DuckGenI18nMessages = DuckGenI18nMessages,
  Messages extends DuckGenI18nMessages = DuckGenI18nMessages,
> = ScopeOrMessages extends string
  ? Record<Lang, Record<ScopeOrMessages, Messages>>
  : Record<Lang, Record<string, ScopeOrMessages>>

/** 🦆
 * 🦆 Convenience alias for the "auth" group dictionary.
 */
export type AuthMessagesDictionary = DuckgenMessageDictionary<'auth'>
